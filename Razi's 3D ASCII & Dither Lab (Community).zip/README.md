
  # Razi's 3D ASCII & Dither Lab (Community)

  This is a code bundle for Razi's 3D ASCII & Dither Lab (Community). The original project is available at https://www.figma.com/design/UKOW16neWk03Kh81uwOXZR/Razi-s-3D-ASCII---Dither-Lab--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  